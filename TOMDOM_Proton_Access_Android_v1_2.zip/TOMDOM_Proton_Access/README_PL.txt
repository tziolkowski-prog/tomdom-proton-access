TOMDOM PROTON ACCESS – wersja demonstracyjna 1.0

CO ZAWIERA
- panel uruchamiany jako aplikacja PWA na Androidzie,
- przycisk otwierający oficjalny Proton Mail,
- pole do przygotowania treści, kopiowania i przekazania do programu pocztowego,
- listę kontrolną przed wysłaniem,
- podstawową pracę offline po pierwszym załadowaniu.

WAŻNE OGRANICZENIE
Ta wersja NIE loguje się do Proton, nie czyta skrzynki, nie pobiera odpowiedzi
i nie wysyła wiadomości automatycznie. Nie zapisuje haseł ani tokenów.
Nie jest to oficjalna aplikacja Proton.

INSTALACJA NA ANDROIDZIE
1. Rozpakuj ZIP na komputerze lub umieść pliki na hostingu obsługującym HTTPS.
2. Otwórz adres strony w Chrome na Androidzie.
3. W menu Chrome wybierz „Zainstaluj aplikację” lub „Dodaj do ekranu głównego”.
4. Uruchom ikonę TOMDOM Proton Access.

UWAGA TECHNICZNA
PWA wymaga HTTPS (albo localhost podczas testów), aby działał Service Worker.
Samo otwarcie index.html z menedżera plików nie zapewni instalacji PWA.

CO JEST POTRZEBNE DO PRAWDZIWEJ INTEGRACJI
Bezpieczny serwer pośredniczący i oficjalnie wspierany sposób dostępu do skrzynki.
Proton Mail Bridge nie działa na Androidzie i wymaga płatnego planu. Nie należy
omijać zabezpieczeń logowania ani przekazywać hasła do zewnętrznej aplikacji.
