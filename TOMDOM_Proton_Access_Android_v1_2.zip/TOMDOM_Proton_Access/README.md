# TOMDOM Proton Access

Mobilny panel PWA po polsku do pomocniczej pracy z Proton Mail.

## Publikacja na GitHub Pages
1. Wgraj wszystkie pliki i foldery z tego pakietu do głównego katalogu repozytorium `tomdom-proton-access`.
2. W repozytorium wybierz Settings → Pages.
3. W sekcji Build and deployment ustaw Source na GitHub Actions.
4. Otwórz zakładkę Actions i poczekaj na zielony przebieg `Deploy TOMDOM Proton Access`.

Po publikacji adres aplikacji:
https://tziolkowski-prog.github.io/tomdom-proton-access/

## Instalacja na Androidzie
Otwórz powyższy adres w Chrome. Wybierz menu ⋮, następnie „Zainstaluj aplikację” lub „Dodaj do ekranu głównego”.

## Funkcje
- otwieranie oficjalnego Proton Mail,
- przygotowanie tematu i treści wiadomości,
- kopiowanie treści,
- przekazanie wiadomości do aplikacji pocztowej przez mailto,
- checklista przed wysłaniem,
- podstawowa pamięć podręczna do pracy offline po pierwszym uruchomieniu.

## Ograniczenia i bezpieczeństwo
To nie jest oficjalna aplikacja Proton. Wersja nie odczytuje skrzynki, nie pobiera odpowiedzi i nie wysyła wiadomości automatycznie. Nie przechowuje haseł, tokenów ani kodów 2FA. Przycisk „Otwórz program pocztowy” korzysta z mechanizmu mailto dostępnego w telefonie; do pracy bezpośrednio w Proton Mail najlepiej użyć przycisku „Otwórz Proton Mail”, a treść skopiować.
